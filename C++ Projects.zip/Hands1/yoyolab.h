class yoyo{
  private:
      int x, y, radius, startangle, endangle, startangle2, endangle2, i;

  public:
      yoyo():x(300), y(300), startangle(0), endangle(180), radius(50),
             startangle2(180), endangle2(360){}
      void draw();
      void deleteyoyo();
      void spin();
};

void yoyo::draw(){
      struct arccoordstype arcinfo[1];
      setcolor(YELLOW);
      arc(x, y, startangle, endangle, radius);
      arc(x, y, startangle2, endangle2, radius);
      getarccoords(&arcinfo[0]);
      line(arcinfo[0].xstart, arcinfo[0].ystart, arcinfo[0].xend, arcinfo[0].yend);      
      line(x,0,x,(y-50));
}

void yoyo::deleteyoyo(){
      struct arccoordstype arcinfo[1];
      setcolor(BLACK);
      arc(x, y, startangle, endangle, radius);
      arc(x, y, startangle2, endangle2, radius);
      getarccoords(&arcinfo[0]);
      line(arcinfo[0].xstart, arcinfo[0].ystart, arcinfo[0].xend, arcinfo[0].yend);      
      line(x,0,x,(y-100));
}

void yoyo::spin() {
  deleteyoyo();

  if (y < 100)
      i = 1;
  if (y > 450)
      i =0;

  if(i)
  {
      y++;
  }
  else
  {
      y--;
  }

  startangle++;
  if (startangle > 360);
   startangle -= 360;

  endangle = endangle++;
  if (endangle > 360);
   endangle -= 360;

  startangle2++;
  if (startangle2 > 360);
   startangle2 -= 360;

  endangle2++;
  if (endangle2 > 360);
   endangle2 -= 360;

  draw();
}

