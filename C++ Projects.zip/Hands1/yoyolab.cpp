#include <iostream>
#include <cstdlib>
#include "winbgim.h"
#include "yoyolab.h"

using namespace std;

int main (int argc, char *argv[])
{
  yoyo yo1;
  char j;
  initwindow(600, 600);
  while(j != 'q')
  {
     yo1.spin();
     delay(3);
     if (kbhit())
     {
       j = getch();
     }
  }
  return 0;
}
