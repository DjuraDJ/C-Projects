//I, Djura Djurickovic, certify that this material is my original work.
//No other person's work has been used without due acknowledgement.


class product
{
public:
       int prodID, copies;
       string name, company;
       float cost;
       double stock;
       
       product(): prodID(0), name(""), company(""), cost(0), stock(0)
       {}

       void add(int prodID);
       void list();
       void addcopy();
       void delcopy();
       void delinv();

}
;

//This function creates a new product
void product::add(int ID)
{     
     prodID = ID;
     cout << "Product ID: " << prodID << endl;
     cin.ignore(100,'\n');
     cout << "Please Enter the name: ";
     getline(cin, name);
     cout << "Please Enter the company: ";
     getline(cin, company);
     cout << "Please Enter the cost: ";
     cin >> cost;
     cin.ignore(100,'\n');
     cout << "Please Enter the quantity in stock: ";
     cin >> stock;
     cout << "Product Added" << endl;
     system("PAUSE");
}

//This will print out all of the product information
void product::list()
{     
     if (prodID > 0)
     {
       cout << prodID << "\t";
       cout << name << "\t\t";
       cout << company << "\t\t";
       cout << setiosflags(ios::showpoint) << setiosflags(ios::fixed) << setprecision(2);
       cout << "$" << cost << "\t";
       cout << stock << endl;
     }
}

//This function will allow the user to add stock to a product
void product::addcopy()
{
     cout << "How many copies would you like to add to stock? ";
     cin >> copies;
     stock += copies;
}

//This function will allow the user to remove stock from a product
void product::delcopy()
{
     cout << "How many copies would you like to remove? ";
     cin >> copies;
     stock -= copies;
}

//This function sets the product ID to 0 so the program will overlook it
void product::delinv()
{
     prodID = 0;
}
