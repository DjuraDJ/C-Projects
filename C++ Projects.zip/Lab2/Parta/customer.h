//I, Djura Djurickovic certify that this material is my original work. No other person's work has been used without due acknowledgement.


class customer
{
public:
       string name, address, city, postal;
       float balance,money;
       
       customer(): name(""), address(""), city(""), postal(""), balance(0)
       {}
       
       void add();
       void deposit();
       void withdrawl();
       void show();

}
;

//Adds all the customer information
void customer::add()
{     
     cout << "Please Enter the name: ";
     getline(cin, name);
     cout << "Please Enter the address: ";
     getline(cin,address);
     cout << "Please Enter the city: ";
     getline(cin,city);
     cout << "Please Enter the postal code (L#L#L#): ";
     cin >> postal;
     cout << "Please Enter the starting balance: ";
     cin >> balance;
     cout << "Customer Added" << endl;
     system("PAUSE");
}

//Outputs a customer information to the screen
void customer::show()
{     
     cout << "Name: " << name << endl;
     cout << "Address: " << address << endl;
     cout << "City: " << city << endl;
     cout << "Postal: " << postal << endl;
     cout << setiosflags(ios::showpoint) << setiosflags(ios::fixed) << setprecision(2);
     cout << "Balance: $" << balance << endl;
}

//Adds money to the balance
void customer::deposit()
{
     cout << "How much would you like to deposit? $";
     cin >> money;
     balance += money;
     cout << setiosflags(ios::showpoint) << setiosflags(ios::fixed) << setprecision(2);
     cout << "$" << money << " successfully deposited" << endl;
}

//Removes money from the balance
void customer::withdrawl()
{
     cout << "How much would you like to withdrawl? $";
     cin >> money;
     balance -= money;
     cout << setiosflags(ios::showpoint) << setiosflags(ios::fixed) << setprecision(2);
     cout << "$" << money << " successfully withdrawled" << endl;
}
