/****************************************************************************

Author:      Djura Djurickovic
Name:        OfficeSupply.cpp
Version:     1.0
Description: This program will demonstrate inheiretence and constructor
             copying
****************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
#include <stdio.h>
#include <stdlib.h>


class OfficeSupply
{
private:
    char* descrip;
    long  stockNo;
    int   quant;
    float price;

public:
    OfficeSupply(const char* description, long stockNumber, int initQuantity, float initPrice)
    {
     //Checks to see if description has atleast 1 character or more
     //If true, descrip is dynamically allocated and loaded with information
     //Else leaves it blank
     if (description != NULL)
     {
        //Dynamically allocates memory for descrip
        //to string length +1 to allow for null character
        descrip = new char[strlen(description) +1];
        strcpy(descrip,description);
     }

     //Loads Private Variables
     stockNo = stockNumber;
     quant = initQuantity;
     price = initPrice;
     }

    //Copy Constructor
    OfficeSupply(const OfficeSupply& otherSupply)
    {
        descrip = new char[strlen(otherSupply.descrip) +1];
        strcpy(descrip,otherSupply.descrip);
        descrip = otherSupply.descrip;
        stockNo = otherSupply.stockNo;
        quant = otherSupply.quant;
        price = otherSupply.price;
    }

    //Deconstructs OfficeSupply
    ~OfficeSupply()
    {
    //Clears allocated memory for descrip
    delete[] descrip;
    }

    //Outputs the information passed into OfficeSupply
    void Display()
    {
    cout << setiosflags(ios::left);
    cout << setw(20) << "Description:" << setiosflags(ios::right) << descrip << endl;
    cout << setw(20) << "Stock Number:" << setiosflags(ios::right) << stockNo << endl;
    cout << setw(20) << "Quantity:" << setiosflags(ios::right) << quant << endl;
    cout << setw(20) << "Price" << setiosflags(ios::right) << setprecision(4)
    << price << endl;
    }

    void Increase(int amt )
    {
       quant += amt;
    }

    void Decrease(int amt )
    {
       quant -= amt;
    }

    void Reprice(float newPrice )
    {
       price = newPrice;
    }
};

//Subclass of OfficeSupply
class Pen : public OfficeSupply
{
private:
char* pColour;
char* iColour;

public:
Pen( const char* description, long stockNumber, int initQuantity,
     float initPrice, char* pcolor, char* icolor ) :
     OfficeSupply(description, stockNumber, initQuantity, initPrice)
      {
          if (pcolor != NULL)
          {
              //Dynamically allocates memory for pColour
              //to string length +1 to allow for null character
              pColour = new char[strlen(pcolor) + 1];
              strcpy(pColour,pcolor);
          }

          if (icolor != NULL)
          {
              //Dynamically allocates memory for iColour
              //to string length +1 to allow for null character
              iColour = new char[strlen(icolor) + 1];
              strcpy(iColour,icolor);
          }
      }
      //Copy Constructor, Parent variables are copied from OfficeSupply
      Pen(Pen& OtherPen) : OfficeSupply(OtherPen)
      {
      pColour = new char[strlen(OtherPen.pColour)+1];
      strcpy(pColour,OtherPen.pColour);
      iColour = new char[strlen(OtherPen.iColour)+1];
      strcpy(iColour,OtherPen.iColour);
}

void Display()
{
      //Calls display in OfficeSupply
      OfficeSupply::Display();
      cout << setiosflags(ios::left);
      cout << setw(20) << "Pen Colour" << setiosflags(ios::right) << pColour << endl;
      cout << setw(20) << "Ink Colour" << setiosflags(ios::right) << iColour << endl;
}
      //Deconstructs Pen and clears allocated memory
      ~Pen()
      {
      delete[] pColour;
      delete[] iColour;
      }
};

//Subclass of Pen
class FountainPen : public Pen
{
private:
char* fType;

public:
FountainPen( const char* description, long stockNumber, int initQuantity,
     float initPrice, char* pcolor, char* icolor, char* pentype ) :
     Pen(description, stockNumber, initQuantity, initPrice, pcolor, icolor)
      {
           if (pentype != NULL)
           {
                //Dynamically allocates memory for fType
                //to string length +1 to allow for null character
                fType = new char[strlen(pentype) +1];
                strcpy(fType,pentype);
           }
      }
//Copy Constructor, Gets other variables from parent
FountainPen(FountainPen& OtherFount) : Pen(OtherFount)
{
    fType = new char[strlen(OtherFount.fType)+1];
     strcpy(fType,OtherFount.fType);
}

void Display()
{
     //Calls Display in Pen
     Pen::Display();
     cout << setiosflags(ios::left);
     cout << setw(20) << "Fill Type" << setiosflags(ios::right)<< fType << "\n\n";
}
      //Deconstructs Fountainpen and clears allocated memory
      ~FountainPen()
      {
      delete[] fType;
      }
};


int main() {

 char* desc = "Amazing Fountain Pen";
 long stock = 7312;
 int quantity = 7;
 float nprice = 77.52;
 char* pencolour = "Green";
 char* inkcolour = "Blue";
 char* ftype = "Top Load";

 OfficeSupply Supply(desc,stock,quantity,nprice);
 OfficeSupply CopiedSupply(Supply);
 //Outputs object information
 Supply.Display();
 cout << "\n";
 //Outputs object information
 CopiedSupply.Display();
 cout << "\n";

 Pen NewPen(desc,stock,quantity,nprice,pencolour,inkcolour);
 Pen CopiedPen(NewPen);
 //Outputs object information
 NewPen.Display();
 cout << "\n";
 //Outputs object information
 CopiedPen.Display();
 cout << "\n";
 
 FountainPen FountPen(desc,stock,quantity,nprice,pencolour,inkcolour,ftype);
 FountainPen CopiedFountPen(FountPen);
 //Outputs object information
 FountPen.Display();
 //Outputs object information
 CopiedFountPen.Display();
 system("PAUSE");
 return 0;
}
