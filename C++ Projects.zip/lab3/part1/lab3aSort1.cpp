/****************************************************************************
//I, Djura Djurickovic certify that this material is my original work. 
No other person's work has been used without due acknowledgement.

Author:      Djura Djurickovic
Name:        lab3aSort1.cpp
Version:     1.0
Description: This program will take an array of numbers, sort them and print
             the ordered list to the screen, as well as show the highlight
             the highest number from the original list
****************************************************************************/

#include <stdio.h>
#include "winbgim.h"
#include <strstream>
#include <string>

int main(int argc, char *argv[])
{
  float x[10] = {2.3, 5.66 ,1.22 ,5 , 6.777 ,3.2 ,5.13 ,2.862 , 1 , 5.01};
  int i,k, ycord;
  float *sorted[10], *temp;
  char output[40];

  initwindow(700,600);
  setbkcolor(BLACK);
  setcolor(BLUE);
  settextstyle(DEFAULT_FONT, 0,2);
  outtextxy(100,50, "Original");
  
  //Sets the pointer sorted to array x
  for (i = 0; i < 10; i++)
  {
      sorted[i] = &x[i];
  }

  //Sorts the pointer sorted
  for (i = 0; i < 10; i++)
  {
      for (k = 0; k < 10; k++)
      {
           if (*sorted[i] < *sorted[k])
           {
               temp = sorted[k];
               sorted[k] = sorted[i];
               sorted[i] = temp;
           }
      }
  }
  
  //Locates the highest number from original array
  for (i = 0; i < 10; i++)
  {
      if (*sorted[9] == x[i])
      {
          k = i;
      }
  }
  
  //Prints Original values and red box      
  ycord = 70;
  for (i = 0; i < 10; i++)
  {
      if (i == k)
      {
         setcolor(RED);
         rectangle(98, ycord - 2, 180, ycord + 18);
         setcolor(BLUE);
         sprintf(output, "%.3f", x[i]);
         outtextxy(100, ycord, output);
         ycord+=20;
      }
      else{
         sprintf(output, "%.3f", x[i]);
         outtextxy(100, ycord, output);
         ycord+=20;
      }
  }

  //Prints sorted values and original values
  setcolor(RED);
  settextstyle(GOTHIC_FONT, 0,2);
  outtextxy(450,50, "Sorted");

  ycord = 70;
  for (i = 0; i < 10; i++)
  {
      sprintf(output, "%.3f", *sorted[i]);
      outtextxy(400, ycord, output);
      ycord+=20;
  }

    ycord = 70;
  for (i = 0; i < 10; i++)
  {
      sprintf(output, "%.3f", x[i]);
      outtextxy(500, ycord, output);
      ycord+=20;
  }
  getch();
  return 0;
}
