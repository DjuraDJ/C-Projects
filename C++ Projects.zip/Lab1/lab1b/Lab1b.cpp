//I, Djura Djurickovic, 000199229 certify that this material is my original work. No other person's work has been used without due acknowledgement.


//---------------------------------------------------------------------
// Lab # 1 Part 1 Q2 - CO856
//
// This program will read in old british currency from the console and convert it
// in modern British Pounds.
//
// Written by Djura Djurickovic
//            
//            
//----------------------------------------------------------------------

#include <stdio.h>       // Standard I/O header
#include <stdlib.h>      // C library for standard functions (system)
#include <string.h>      // C style strings
#include <iomanip>
#include <fstream>

using namespace std;

// main function - start of the program

main()
{
   float pent, pnd, shill;
   
   //Prompts user for Pounds, Shillings, Pence
   cout << "Please Enter Pounds: ";
   cin >> pnd;
   cout << "Please Enter Shillings: ";
   cin >> shill;
   cout << "Please Enter Pence: ";
   cin >> pent;
   
   //Calculates the conversion from old system to new
   pent /= 12;
   shill += pent;
   shill /= 20;
   pnd += shill;
   
   //Outputs the new value of the british pound
   cout << setiosflags(ios::showpoint) << setiosflags(ios::fixed) << setprecision(2);
   cout << "Decimal pounds = \x9c" << pnd << endl;      
   system ("PAUSE");
}



