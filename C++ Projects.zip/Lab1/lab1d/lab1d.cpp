//I, Djura Djurickovic, 000199229 certify that this material is my original work. No other person's work has been used without due acknowledgement.

//---------------------------------------------------------------------
// Lab # 1 Part 2 Q2 - CO856
//
// 
// The user will enter a word and will proceed to search a file for
// exact and incasesensitive matches
//
// Written by Djura Djurickovic
//            
//            
//----------------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <iomanip>
using namespace std;
// main function - start of the program

main()
{
   string astring, astring1, filestring, filestring1;
   int strlength, i, match, ptmatch;
   ifstream TextFile;
     
   cout << "Please enter the word you would like to search: ";
   getline(cin,astring);
   
   while (astring != "")
   {
   match = 0;
   ptmatch = 0;   
   TextFile.open("Text.txt");
   if (TextFile)
   {
      while (!TextFile.eof())
      {
         TextFile >> filestring;
         if (astring.compare(filestring)==0)
         {
            match++;
         }
         
         strlength = filestring.length();
         filestring1 = filestring;
         
         for (i = 0; i < strlength; i++)
         {
            filestring1[i] = toupper(filestring1[i]);
         }
               
         strlength = astring.length();
         astring1 = astring;         
         
         for (i = 0; i < strlength; i++)
         {
            astring1[i] = toupper(astring1[i]);            
         }
         
         if (astring1.compare(filestring1)==0)
         {
            ptmatch++;            
         }
      }      

       TextFile.close();
   }
   else
     cout << "Open of file failed\n";
   
     cout << "There are " << match << " perfect matches" << endl;
     cout << "There are " << ptmatch << " case insensitive matches" << endl <<endl;
     
     
     cout << "Please enter the word you would like to search: ";
     getline(cin,astring);
   }
   //system ("PAUSE");
}

