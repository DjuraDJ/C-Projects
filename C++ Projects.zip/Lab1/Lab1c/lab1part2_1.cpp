//---------------------------------------------------------------------
// Lab # 1 Part 2 Q1 - CO856
//
// 
// Manipulation of strings
//
// Written by Djura Djurickovic
//            
//            
//----------------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;
// main function - start of the program

main()
{
   string astring;
   int strlength, i, letcnt, punct, wrdcnt;
   
   //Collects a string entered by the user
   cout << "Please Enter a String: ";
   getline(cin, astring);
   
   //Gets the length of the string entered
   strlength = astring.length();
   cout << "The length of the string is: " << strlength;
   cout << "\n";
   letcnt = 0;
   punct = 0;
   //Checks for punctuation characters and characters
   //matching the first letter
   for (i = 0; i < strlength; i++)
   {
      if (astring.at(0) == astring.at(i))
         letcnt++;
      if (ispunct(astring.at(i)))
          punct++;
   }

   cout << "The number of occurances of the first letter is : " << letcnt << endl;
   cout << "The number of punctuation characters entered is : " << punct << endl;
   
     
   system ("PAUSE");
}

