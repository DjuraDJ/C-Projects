//---------------------------------------------------------------------
// Lab # 1 Part 1 Q1 - CO856
//
// This program will read in the data from an ASCII data file and
// write a formatted table to the screen.
//
// Written by Djura Djurickovic
//            
//            
//----------------------------------------------------------------------

#include <stdio.h>       // Standard I/O header
#include <stdlib.h>      // C library for standard functions (system)
#include <string.h>      // C style strings
#include <iomanip>
#include <fstream>

using namespace std;

// main function - start of the program

main()
{
   int   i, iStudIndex;
   ifstream GradeFile;

   // Open the Input file for reading

   GradeFile.open("SGrades.txt");
   if (GradeFile != NULL)
   {
      int iNumStudents;
      int iNumCourses;
      int i;
      int iStudIndex, iCourseIndex;
      
      GradeFile >> iNumCourses >> iNumStudents;
      for (i=0; i<iNumCourses; i++)
      {
         char sCourseCode[20];
         GradeFile >> sCourseCode;
         cout << setw(7) << sCourseCode;
      }
      cout << endl;
      // Output all of the Student information into the table

      for (iStudIndex=0; iStudIndex<iNumStudents; iStudIndex++)
      {
         char szStudentNum[10];
         int iTotStud = 0;
         GradeFile >> szStudentNum;

         for (iCourseIndex=0; iCourseIndex < iNumCourses; iCourseIndex++)
         {
            float fGrade;
            GradeFile >> fGrade;
            cout << setiosflags(ios::showpoint);            
            cout << setw(7) << setprecision(3) << fGrade;
         }
         cout << endl;
       }

       GradeFile.close();
   }
   else
     cout << "Open of file failed\n";

   system ("PAUSE");
}



