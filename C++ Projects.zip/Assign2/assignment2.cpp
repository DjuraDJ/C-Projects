/*****************************************************************************
 * I Djura Djurickovic certify that this material is my original work.       *
 * No other person's work has been used without due acknowledgement.         *
 *                                                                           *
 * Autor:       Djura Djurickovic                                            *
 * Course:      CO856                                                        *
 * Instructor:  N. Corkigian                                                 *
 * Description: CO856 Assignment2 Design a small banking system that allows  *
 *              users to add clients, add/edit account info and calculates   *
 *              interest                                                     *
 *              NOTE: This program is NOT fully functional                   *
 *****************************************************************************/
#include <iostream>
#include <string>
#include <stdlib.h>
#include <conio.h>
#include <fstream>
#include "a2class.h"
using namespace std;


//Prototypes
string printmainmenu();
clientlist clientadd(clientlist);
clientlist clientload(clientlist);
int clientmenu(clientlist,acclist, int);
acclist accmenu(acclist, int);
clientlist clientdel(clientlist);
acclist accload(acclist);
acclist accadd(acclist, int);

int main()
{
    string choice = "3";
    int n = 2;
    clientlist mohawk;
    acclist mohawkacc;
    mohawk = clientload(mohawk);
    mohawkacc = accload(mohawkacc);
    while(choice != "1"){
    if (choice =="2")
    break;
    choice = printmainmenu();
    }
    if (choice == "1")
    {
    while(n != 1){
    n = clientmenu(mohawk, mohawkacc,n);
    }
    }
    else if (choice == "2")
    return 0;
    return 0;
}

//The initial start up menu
string printmainmenu()
{
     string choice;
     clrscr();
     gotoxy(20,1);
     textcolor(LIGHTBLUE);
     cout << "Mohawk Bank" << endl << endl <<endl;
     textcolor(YELLOW);
     cout << "1. View Client Data" << endl;
     cout << "2. Quit" << endl << endl;
     textcolor(WHITE);
     cout << "   Enter Choice: ";
     cin >> choice;
     if (choice == "1"  || choice == "2")
     return choice;
     else
     {
     cout << "INVALID ENTRY" << endl;
     system("PAUSE");
     return "3";
     }
}

//Allows user to manually enter new clients
clientlist clientadd(clientlist mohawk)
{
    long socnum;
    string fstname, lstname, address, phone,temp;
    clrscr();
    cin.ignore();
    cout << "Enter 9 digit SIN(nnnnnnnnn): ";
    getline(cin,temp);
    socnum = atoi(temp.c_str());
    cout << "Enter First Name: ";
    getline(cin,fstname);
    cout << "Enter Last Name: ";
    getline(cin,lstname);
    cout << "Enter Address: ";
    getline(cin,address);
    cout << "Enter Phone: ";
    getline(cin,phone);
    mohawk.additem(socnum,fstname,lstname,address,phone);
    return mohawk;
}

/*clientlist clientdel(clientlist mohawk)
{
    long num;
    clrscr();
    mohawk.display();
    cout << "Please enter the 9-digit SIN for the client you wish to remove: ";
    cin >> num;
    mohawk.deleteitem(num);
}*/

//Loads clients.txt into the clientlist link list
clientlist clientload(clientlist mohawk)
{
    long socnum;
    string fstname, lstname, address, phone, record, temp;
    ifstream client ("clients.txt");
    while (client){
            getline(client, record);
            if (!client)
                break;
    //extract SIN from string
    temp = record.substr(0, record.find(","));
    socnum = atoi(temp.c_str());
    record.erase(0, record.find(",") + 1);
    //extract the first name from string
    fstname = record.substr(0, record.find(","));
    record.erase(0, record.find(",") + 1);
    //extract the last name from string
    lstname = record.substr(0, record.find(","));
    record.erase(0, record.find(",") + 1);
    //extract the address from string
    address = record.substr(0, record.find(","));
    record.erase(0, record.find(",") + 1);
    //extract the phone from string
    phone = record.substr(0, record.find(","));
    record.erase(0, record.find(",") + 1);
    mohawk.additem(socnum,fstname,lstname,address,phone);
    }
    return mohawk;
}

//Menu with all the options corresponding to accounts
acclist accmenu(acclist mohawkacc, int nsoc)
{
     char choice;
     textcolor(YELLOW);
     cout << "1. Add Account" << endl;
     cout << "2. Back to Client" << endl <<endl;
     textcolor(WHITE);
     cout << "   Enter Choice: ";
     cin >> choice;
     switch (choice)
     {
            //Add new account
            case '1':
                 {
                 mohawkacc = accadd(mohawkacc, nsoc);
                 break;
                 }
            //Back to client menu
            case '2':
                 {
                 break;
                 }
     }

 return mohawkacc;
}

//Menu with all the options coresponding to clients
int clientmenu(clientlist mohawk, acclist mohawkacc, int n)
{
     char choice;
     long nsoc;
     clrscr();
     gotoxy(20,1);
     textcolor(LIGHTBLUE);
     cout << "Clients" << endl << endl <<endl;
     textcolor(YELLOW);
     mohawk.display();
     cout << endl << endl;
     cout << "1. Add Client" << endl;
     cout << "2. Delete Client" << endl;
     cout << "3. Edit Client" << endl;
     cout << "4. Quit" << endl << endl;
     textcolor(WHITE);
     cout << "   Enter Choice: ";
     cin >> choice;
     switch (choice)
     {
            //Add new client
            case '1':
                 {
                 mohawk = clientadd(mohawk);
                 n = 2;
                 break;
                 }
            //Delete client
            case '2':
                 {
                 //mohawk = clientdel(mohawk);
                 cout << "Function not enabled" << endl;
                 system("PAUSE");
                 n = 2;
                 break;
                 }
            //Edit accounts for clients
            case '3':
                 {
                 cout << "Enter the SIN to display accounts: ";
                 cin >> nsoc;
                 clrscr();
                 cout << "              Accounts" <<endl<<endl;
                 mohawkacc.ndisplay(nsoc);
                 mohawkacc = accmenu(mohawkacc, nsoc);
                 n = 2;
                 break;
                 }
            //Quit
            case '4':
                 {
                 n = 1;
                 break;
                 }
            //All other input invalid
            default:
                 {
                  cout << "INVALID ENTRY";
                  system("PAUSE");
                 }
     }
   return n;
}

//Loads the accounts.txt file into the accounts linklist
acclist accload(acclist mohawkacc)
{
    long socid;
    int accid;
    float balance;
    string type, record, temp;
    ifstream acc ("accounts.txt");
    while (acc){
            getline(acc, record);
            if (!acc)
                break;
    //extract SIN from string
    temp = record.substr(0, record.find(","));
    socid = atoi(temp.c_str());
    record.erase(0, record.find(",") + 1);
    //extract the Account ID from string
    temp = record.substr(0, record.find(","));
    accid = atoi(temp.c_str());
    record.erase(0, record.find(",") + 1);
    //extract the Account type from string
    type = record.substr(0, record.find(","));
    record.erase(0, record.find(",") + 1);
    //extract the balance from string
    temp = record.substr(0, record.find(","));
    balance = atoi(temp.c_str());
    record.erase(0, record.find(",") + 1);
    mohawkacc.nadditem(socid,accid,type,balance);
    }
    return mohawkacc;
}

//This allows the user to manually add accounts to clients
acclist accadd(acclist mohawkacc, int nsoc)
{
    long socid = nsoc;
    int accid;
    float balance;
    string type, temp;
    clrscr();
    cin.ignore();
    cout << "Enter Account ID: ";
    getline(cin,temp);
    accid = atoi(temp.c_str());
    cout << "Enter Account Type: ";
    getline(cin,type);
    cout << "Enter Balance: ";
    getline(cin,temp);
    balance = atof(temp.c_str());
    mohawkacc.nadditem(socid,accid,type,balance);
    return mohawkacc;
}
