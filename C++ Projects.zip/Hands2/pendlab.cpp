#include <iostream>
#include <cstdlib>
#include "winbgim.h"
#include "pendlab.h"

using namespace std;

int main (int argc, char *argv[])
{
  pend pend1;
  char j;
  initwindow(600, 600);
  while(j != 'q')
  {
     pend1.swing();
     delay(10);
     if (kbhit())
     {
       j = getch();
     }
  }
  return 0;
}
