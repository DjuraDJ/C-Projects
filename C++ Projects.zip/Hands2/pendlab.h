class pend{
  private:
      int x, y, radius, startangle, endangle, i;

  public:
      pend():x(300), y(300), startangle(270), endangle(90), radius(200), i(1){}
      void draw();
      void deletepend();
      void swing();
};

void pend::draw(){
      struct arccoordstype arcinfo[1];
      setcolor(BLACK);
      arc(x, y, startangle, endangle, radius);      
      getarccoords(&arcinfo[0]);
      setcolor(YELLOW);
      circle(arcinfo[0].xstart, arcinfo[0].ystart, 50);
      line(x,0,arcinfo[0].xstart,arcinfo[0].ystart -50);     
}

void pend::deletepend(){
      struct arccoordstype arcinfo[1];
      setcolor(BLACK);
      arc(x, y, startangle, endangle, radius);
      getarccoords(&arcinfo[0]);
      circle(arcinfo[0].xstart, arcinfo[0].ystart, 50);
      line(x,0,arcinfo[0].xstart,arcinfo[0].ystart -50);
}

void pend::swing() {
  deletepend();
  
  if (endangle == 0)
     i = 0;
  if (endangle == 180)
     i = 1;
  
  if (i){
     startangle--;
     endangle--;
  }
  else{
     startangle++;
     endangle++;
  }
       
  draw();
}

